#!/usr/bin/env python3
"""
CLI entry point for the Binance Futures Testnet trading bot.
Place MARKET or LIMIT orders via command-line arguments.
"""

import argparse
import os
import sys

# Ensure package is importable when run from project root
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from bot import (
    BinanceFuturesClient,
    BinanceFuturesClientError,
    ValidationError,
    place_order,
    format_order_response,
    format_order_summary,
)
from bot.logging_config import setup_logging

DEFAULT_BASE_URL = "https://testnet.binancefuture.com"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Place MARKET or LIMIT orders on Binance Futures Testnet (USDT-M)."
    )
    parser.add_argument(
        "symbol",
        type=str,
        help="Trading pair symbol (e.g. BTCUSDT)",
    )
    parser.add_argument(
        "side",
        type=str,
        help="Order side: BUY or SELL (case-insensitive)",
    )
    parser.add_argument(
        "order_type",
        type=str,
        help="Order type: MARKET or LIMIT (case-insensitive)",
    )
    parser.add_argument(
        "quantity",
        type=str,
        help="Order quantity (e.g. 0.001)",
    )
    parser.add_argument(
        "--price",
        type=str,
        default=None,
        help="Limit price (required for LIMIT orders)",
    )
    parser.add_argument(
        "--api-key",
        type=str,
        default=os.environ.get("BINANCE_API_KEY"),
        help="Binance API key (or set BINANCE_API_KEY)",
    )
    parser.add_argument(
        "--api-secret",
        type=str,
        default=os.environ.get("BINANCE_API_SECRET"),
        help="Binance API secret (or set BINANCE_API_SECRET)",
    )
    parser.add_argument(
        "--base-url",
        type=str,
        default=os.environ.get("BINANCE_FUTURES_BASE_URL", DEFAULT_BASE_URL),
        help=f"Futures API base URL (default: {DEFAULT_BASE_URL})",
    )
    parser.add_argument(
        "--log-file",
        type=str,
        default=None,
        help="Log file path (default: logs/trading_bot.log)",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Only print order result, no request summary",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    # Setup logging first
    setup_logging(log_file=args.log_file)
    import logging
    logger = logging.getLogger("bot")

    if not args.api_key or not args.api_secret:
        print("ERROR: API credentials required. Set BINANCE_API_KEY and BINANCE_API_SECRET or use --api-key and --api-secret.", file=sys.stderr)
        return 1

    client = BinanceFuturesClient(
        api_key=args.api_key,
        api_secret=args.api_secret,
        base_url=args.base_url,
    )

    try:
        # Validate and get normalized params for summary
        from bot.validators import validate_order_params
        params = validate_order_params(
            args.symbol,
            args.side,
            args.order_type,
            args.quantity,
            args.price,
        )
    except ValidationError as e:
        print(f"Validation error: {e}", file=sys.stderr)
        logger.exception("Validation failed")
        return 1

    if not args.quiet:
        print(format_order_summary(
            params["symbol"],
            params["side"],
            params["order_type"],
            params["quantity"],
            params["price"],
        ))
        print()

    try:
        response = place_order(
            client,
            symbol=args.symbol,
            side=args.side,
            order_type=args.order_type,
            quantity=args.quantity,
            price=args.price,
        )
    except ValidationError as e:
        print(f"Validation error: {e}", file=sys.stderr)
        logger.exception("Validation failed")
        return 1
    except BinanceFuturesClientError as e:
        print(f"API/Network error: {e}", file=sys.stderr)
        logger.exception("Order failed")
        return 1

    print(format_order_response(response))
    status = response.get("status", "")
    if status in ("NEW", "FILLED", "PARTIALLY_FILLED"):
        print("\nSUCCESS: Order placed successfully.")
    else:
        print(f"\nOrder status: {status} (check exchange for details).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
