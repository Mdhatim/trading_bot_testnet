"""Binance Futures (USDT-M) API client for testnet."""

import hashlib
import hmac
import logging
import time
from urllib.parse import urlencode

import requests

logger = logging.getLogger("bot.client")

# User-specified testnet base URL
DEFAULT_BASE_URL = "https://testnet.binancefuture.com"


class BinanceFuturesClientError(Exception):
    """API or network error from Binance Futures client."""

    pass


class BinanceFuturesClient:
    """
    Lightweight client for Binance USDT-M Futures Testnet.
    Uses REST with HMAC SHA256 signing.
    """

    def __init__(
        self,
        api_key: str,
        api_secret: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = 10,
        recv_window: int = 5000,
    ):
        self.api_key = api_key
        self.api_secret = api_secret
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.recv_window = recv_window

    def _sign(self, params: dict) -> str:
        """Compute HMAC SHA256 signature for query string."""
        query = urlencode(params)
        signature = hmac.new(
            self.api_secret.encode("utf-8"),
            query.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        return signature

    def _request(
        self,
        method: str,
        path: str,
        params: dict | None = None,
        signed: bool = True,
    ) -> dict:
        """
        Send HTTP request. For signed endpoints, adds timestamp, recvWindow, and signature.
        """
        url = f"{self.base_url}{path}"
        params = dict(params) if params else {}

        if signed:
            params["timestamp"] = int(time.time() * 1000)
            params["recvWindow"] = self.recv_window
            params["signature"] = self._sign(params)

        headers = {"X-MBX-APIKEY": self.api_key}

        try:
            if method.upper() == "GET":
                resp = requests.get(url, params=params, headers=headers, timeout=self.timeout)
            else:
                resp = requests.post(
                    url,
                    data=params,
                    headers={**headers, "Content-Type": "application/x-www-form-urlencoded"},
                    timeout=self.timeout,
                )
        except requests.exceptions.Timeout as e:
            logger.exception("Request timeout: %s", url)
            raise BinanceFuturesClientError(f"Request timeout: {e}") from e
        except requests.exceptions.RequestException as e:
            logger.exception("Request failed: %s", e)
            raise BinanceFuturesClientError(f"Network error: {e}") from e

        logger.info("API %s %s -> %s", method, path, resp.status_code)
        logger.debug("Response body: %s", resp.text[:500] if resp.text else "")

        try:
            data = resp.json()
        except ValueError:
            raise BinanceFuturesClientError(f"Invalid JSON response: {resp.text[:200]}")

        if not resp.ok:
            code = data.get("code", resp.status_code)
            msg = data.get("msg", resp.text)
            logger.error("API error: code=%s msg=%s", code, msg)
            raise BinanceFuturesClientError(f"API error [{code}]: {msg}")

        return data

    def place_order(
        self,
        symbol: str,
        side: str,
        order_type: str,
        quantity: float,
        price: float | None = None,
        time_in_force: str = "GTC",
        new_order_resp_type: str = "RESULT",
    ) -> dict:
        """
        Place a single order. POST /fapi/v1/order
        For MARKET: quantity only. For LIMIT: quantity, price, timeInForce.
        new_order_resp_type=RESULT returns full order details (executedQty, avgPrice, etc.).
        """
        params = {
            "symbol": symbol,
            "side": side,
            "type": order_type,
            "quantity": quantity,
            "newOrderRespType": new_order_resp_type,
        }
        if order_type == "LIMIT":
            params["price"] = price
            params["timeInForce"] = time_in_force

        logger.info("Placing order: %s", params)
        return self._request("POST", "/fapi/v1/order", params=params)
