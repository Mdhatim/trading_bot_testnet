"""Order placement logic: validation + client call + response formatting."""

import logging

from bot.client import BinanceFuturesClient, BinanceFuturesClientError
from bot.validators import ValidationError, validate_order_params

logger = logging.getLogger("bot.orders")


def place_order(
    client: BinanceFuturesClient,
    symbol: str,
    side: str,
    order_type: str,
    quantity: str | float,
    price: str | float | None = None,
) -> dict:
    """
    Validate inputs, place order via client, return API response.
    Raises ValidationError or BinanceFuturesClientError on failure.
    """
    params = validate_order_params(symbol, side, order_type, quantity, price)
    logger.info(
        "Order request: symbol=%s side=%s type=%s quantity=%s price=%s",
        params["symbol"],
        params["side"],
        params["order_type"],
        params["quantity"],
        params["price"],
    )

    response = client.place_order(
        symbol=params["symbol"],
        side=params["side"],
        order_type=params["order_type"],
        quantity=params["quantity"],
        price=params["price"],
    )
    return response


def format_order_summary(
    symbol: str,
    side: str,
    order_type: str,
    quantity: float,
    price: float | None,
) -> str:
    """Human-readable summary of the order request."""
    lines = [
        "--- Order request ---",
        f"  Symbol:     {symbol}",
        f"  Side:       {side}",
        f"  Type:       {order_type}",
        f"  Quantity:   {quantity}",
    ]
    if price is not None:
        lines.append(f"  Price:      {price}")
    return "\n".join(lines)


def format_order_response(response: dict) -> str:
    """Human-readable summary of the order response."""
    order_id = response.get("orderId", "N/A")
    status = response.get("status", "N/A")
    executed_qty = response.get("executedQty", "0")
    avg_price = response.get("avgPrice", "0")
    orig_qty = response.get("origQty", "N/A")
    client_order_id = response.get("clientOrderId", "N/A")

    lines = [
        "--- Order response ---",
        f"  Order ID:       {order_id}",
        f"  Client Order:   {client_order_id}",
        f"  Status:         {status}",
        f"  Orig. quantity: {orig_qty}",
        f"  Executed qty:   {executed_qty}",
        f"  Avg. price:     {avg_price}",
    ]
    return "\n".join(lines)
