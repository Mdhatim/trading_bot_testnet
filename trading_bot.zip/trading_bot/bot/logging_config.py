"""Logging configuration for the trading bot."""

import logging
import os
from pathlib import Path

# Default log directory (project root / logs)
LOG_DIR = Path(__file__).resolve().parent.parent / "logs"
LOG_FILE = LOG_DIR / "trading_bot.log"


def setup_logging(
    log_file: str | Path | None = None,
    level: int = logging.INFO,
    console: bool = True,
) -> logging.Logger:
    """
    Configure logging to file and optionally console.
    Returns the root logger for the 'bot' package.
    """
    log_path = Path(log_file) if log_file else LOG_FILE
    log_path.parent.mkdir(parents=True, exist_ok=True)

    # Use env to override log file location
    env_log = os.environ.get("TRADING_BOT_LOG_FILE")
    if env_log:
        log_path = Path(env_log)
        log_path.parent.mkdir(parents=True, exist_ok=True)

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    root = logging.getLogger("bot")
    root.setLevel(level)

    # Avoid duplicate handlers when called multiple times
    if not root.handlers:
        fh = logging.FileHandler(log_path, encoding="utf-8")
        fh.setLevel(level)
        fh.setFormatter(formatter)
        root.addHandler(fh)

        if console:
            ch = logging.StreamHandler()
            ch.setLevel(level)
            ch.setFormatter(formatter)
            root.addHandler(ch)

    return root
