"""Input validation for order parameters."""

import re

# Allowed sides and order types
SIDES = {"BUY", "SELL"}
ORDER_TYPES = {"MARKET", "LIMIT"}

# Symbol pattern: alphanumeric, typically BASEQUOTE e.g. BTCUSDT
SYMBOL_PATTERN = re.compile(r"^[A-Z0-9]{2,20}$")


class ValidationError(ValueError):
    """Raised when user input fails validation."""

    pass


def validate_symbol(symbol: str) -> str:
    """Validate and normalize symbol (e.g. BTCUSDT)."""
    if not symbol or not isinstance(symbol, str):
        raise ValidationError("Symbol is required and must be a non-empty string.")
    s = symbol.strip().upper()
    if not SYMBOL_PATTERN.match(s):
        raise ValidationError(
            f"Invalid symbol '{symbol}'. Use uppercase letters/numbers (e.g. BTCUSDT)."
        )
    return s


def validate_side(side: str) -> str:
    """Validate side: BUY or SELL."""
    if not side or not isinstance(side, str):
        raise ValidationError("Side is required and must be BUY or SELL.")
    s = side.strip().upper()
    if s not in SIDES:
        raise ValidationError(f"Invalid side '{side}'. Must be BUY or SELL.")
    return s


def validate_order_type(order_type: str) -> str:
    """Validate order type: MARKET or LIMIT."""
    if not order_type or not isinstance(order_type, str):
        raise ValidationError("Order type is required and must be MARKET or LIMIT.")
    t = order_type.strip().upper()
    if t not in ORDER_TYPES:
        raise ValidationError(f"Invalid order type '{order_type}'. Must be MARKET or LIMIT.")
    return t


def validate_quantity(quantity: str | float) -> float:
    """Validate quantity as a positive number."""
    try:
        if isinstance(quantity, str):
            q = float(quantity.strip())
        else:
            q = float(quantity)
    except (TypeError, ValueError):
        raise ValidationError(f"Quantity must be a positive number, got: {quantity!r}")
    if q <= 0:
        raise ValidationError("Quantity must be greater than 0.")
    return q


def validate_price(price: str | float) -> float:
    """Validate price as a positive number."""
    try:
        if isinstance(price, str):
            p = float(price.strip())
        else:
            p = float(price)
    except (TypeError, ValueError):
        raise ValidationError(f"Price must be a positive number, got: {price!r}")
    if p <= 0:
        raise ValidationError("Price must be greater than 0.")
    return p


def validate_order_params(
    symbol: str,
    side: str,
    order_type: str,
    quantity: str | float,
    price: str | float | None = None,
) -> dict:
    """
    Validate all order parameters. For LIMIT orders, price is required.
    Returns a dict with validated/normalized values.
    """
    symbol = validate_symbol(symbol)
    side = validate_side(side)
    order_type = validate_order_type(order_type)
    quantity = validate_quantity(quantity)

    if order_type == "LIMIT":
        if price is None or (isinstance(price, str) and not price.strip()):
            raise ValidationError("Price is required for LIMIT orders.")
        price = validate_price(price)
    else:
        price = None

    return {
        "symbol": symbol,
        "side": side,
        "order_type": order_type,
        "quantity": quantity,
        "price": price,
    }
