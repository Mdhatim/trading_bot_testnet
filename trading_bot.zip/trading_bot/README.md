# Trading Bot — Binance Futures Testnet (USDT-M)

A small Python application to place **Market** and **Limit** orders on **Binance Futures Testnet** (USDT-M) with a clean structure, logging, and CLI.

## Setup

### 1. Register and activate Binance Futures Testnet

- Go to [Binance Futures Testnet](https://testnet.binancefuture.com) (or the testnet URL you use).
- Register / log in and activate your Futures Testnet account.

### 2. Generate API credentials

- In the testnet site, open API Management and create an API key.
- Save the **API Key** and **Secret Key**; the secret is shown only once.

### 3. Install dependencies

```bash
cd trading_bot
python -m venv .venv
.venv\Scripts\activate   # Windows
# source .venv/bin/activate   # Linux/macOS
pip install -r requirements.txt
```

### 4. Configure credentials

**Option A — Environment variables (recommended)**

```bash
set BINANCE_API_KEY=your_api_key_here
set BINANCE_API_SECRET=your_api_secret_here
```

Or create a `.env` file (see `.env.example`) and load it with a tool like `python-dotenv` if you add it.

**Option B — CLI arguments**

Use `--api-key` and `--api-secret` (avoid in shared environments).

## How to run

All API calls use the testnet base URL: **https://testnet.binancefuture.com**.

### MARKET order

```bash
python cli.py BTCUSDT BUY MARKET 0.001
python cli.py BTCUSDT SELL MARKET 0.001
```

### LIMIT order (price required)

```bash
python cli.py BTCUSDT BUY LIMIT 0.001 --price 50000
python cli.py BTCUSDT SELL LIMIT 0.001 --price 60000
```

### Optional arguments

| Argument       | Description                                |
|----------------|--------------------------------------------|
| `--price`      | Limit price (required for LIMIT)           |
| `--api-key`    | API key (or `BINANCE_API_KEY`)             |
| `--api-secret` | API secret (or `BINANCE_API_SECRET`)      |
| `--base-url`   | Override base URL (default: testnet URL)   |
| `--log-file`   | Custom log file path                       |
| `--quiet`      | Only print order result                    |

### Examples (after setting env vars)

```bash
# Market buy 0.001 BTC
python cli.py BTCUSDT BUY MARKET 0.001

# Limit sell 0.001 BTC at 95000 USDT
python cli.py BTCUSDT SELL LIMIT 0.001 --price 95000
```

## Project structure

```
trading_bot/
  bot/
    __init__.py       # Package exports
    client.py         # Binance Futures API client (REST + HMAC)
    orders.py         # Order placement and response formatting
    validators.py     # Input validation (symbol, side, type, quantity, price)
    logging_config.py # File + console logging
  cli.py              # CLI entry point (argparse)
  README.md
  requirements.txt
  .env.example
  logs/               # Created on first run; trading_bot.log
```

## Logs

- Logs are written to **`logs/trading_bot.log`** by default.
- Override with `--log-file path/to/file.log` or env `TRADING_BOT_LOG_FILE`.
- Each run logs request parameters, API responses, and errors.

## Assumptions

- **Python 3.x** (tested on 3.10+).
- **Testnet only**: base URL is `https://testnet.binancefuture.com`; no mainnet keys in this app.
- **USDT-M Futures** only (symbols like BTCUSDT).
- **HMAC API keys** (not RSA).
- **One-way mode** (no `positionSide`); default on testnet.
- For **LIMIT** orders, `timeInForce` is **GTC** (Good-Til-Cancel).

## Error handling

- **Validation**: invalid symbol, side, type, quantity, or missing price for LIMIT → clear message and non-zero exit.
- **API errors**: invalid keys, balance, symbol, etc. → message and logged.
- **Network**: timeouts and connection errors → raised and logged.

## Deliverables checklist

- [x] Place MARKET and LIMIT orders on Binance Futures Testnet (USDT-M).
- [x] Support BUY and SELL.
- [x] CLI with symbol, side, order type, quantity, price (for LIMIT).
- [x] Clear output: request summary, response (orderId, status, executedQty, avgPrice), success/failure.
- [x] Structured code (client/API layer + CLI layer).
- [x] Logging of requests, responses, errors to a log file.
- [x] Exception handling for invalid input, API errors, network failures.
- [x] `requirements.txt` and `README.md` with setup and run examples.

To produce **log files** for one MARKET and one LIMIT order, run the two example commands above and then copy or attach `logs/trading_bot.log` (or the log file you specified).
